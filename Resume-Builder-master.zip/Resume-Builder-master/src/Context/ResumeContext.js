import { createContext } from "react";

const ResumeContext = createContext();

export default ResumeContext